using Avalonia;
using Avalonia.Controls;
using Avalonia.Layout;
using Avalonia.Media;
using Avalonia.Threading;
using GamerVII.Notification.Avalonia;
using Gml.Client;
using Gml.Client.Helpers;
using Gml.Client.Models;
using Gml.Launcher.Assets;
using Gml.Launcher.Core;
using Gml.Launcher.Core.Exceptions;
using Gml.Launcher.Core.Helpers;
using Gml.Launcher.Core.Services;
using Gml.Launcher.Models;
using Gml.Launcher.ViewModels.Base;
using Gml.Launcher.ViewModels.Components;
using GmlCore.Interfaces.Enums;
using ReactiveUI;
using ReactiveUI.Fody.Helpers;
using Sentry;
using Splat;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Reactive.Concurrency;
using System.Reactive.Disposables;
using System.Reactive.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Input;
using Gml.Client.Extensions;
using Gml.Client.Interfaces;
using Gml.Dto.Messages;
using Gml.Dto.News;
using Gml.Dto.Profile;
using GameLoader = GmlCore.Interfaces.Enums.GameLoader;
using IUser = GmlCore.Interfaces.User.IUser;

namespace Gml.Launcher.ViewModels.Pages;

public class OverviewPageViewModel : PageViewModelBase
{
    private readonly IDisposable? _closeEvent;
    private readonly IGmlClientManager _gmlManager;
    private readonly IDisposable? _loadedLoaded;
    private readonly MainWindowViewModel _mainViewModel;
    private readonly IDisposable? _maxCountLoaded;
    private readonly IObservable<bool> _onClosed;
    private readonly LogHandler _logHandler;
    private readonly IDisposable _profileNameChanged;
    private readonly IStorageService _storageService;
    private readonly ISystemService _systemService;
    private readonly IBackendChecker _backendChecker;
    private readonly ISettingsService _settingsService;
    private readonly IDisposable? _speedSubscription;

    internal OverviewPageViewModel(IScreen screen,
        ILauncherUser user,
        IObservable<bool> onClosed,
        IGmlClientManager? gmlManager = null,
        ISystemService? systemService = null,
        IStorageService? storageService = null,
        ISettingsService? settingsService = null,
        IBackendChecker? backendChecker = null,
        LogHandler? logHandler = null) : base(screen)
    {
        _mainViewModel = screen as MainWindowViewModel ?? throw new Exception("Not valid screen");
        User = user;
        _onClosed = onClosed;

        _logHandler = logHandler
                      ?? Locator.Current.GetService<LogHandler>()
                      ?? throw new ServiceNotFoundException(typeof(LogHandler));

        _systemService = systemService
                         ?? Locator.Current.GetService<ISystemService>()
                         ?? throw new ServiceNotFoundException(typeof(ISystemService));

        _storageService = storageService
                          ?? Locator.Current.GetService<IStorageService>()
                          ?? throw new ServiceNotFoundException(typeof(IStorageService));

        _gmlManager = gmlManager
                      ?? Locator.Current.GetService<IGmlClientManager>()
                      ?? throw new ServiceNotFoundException(typeof(IGmlClientManager));

        _backendChecker = backendChecker
                          ?? Locator.Current.GetService<IBackendChecker>()
                          ?? throw new ServiceNotFoundException(typeof(IBackendChecker));

        _settingsService = settingsService
                           ?? Locator.Current.GetService<ISettingsService>()
                           ?? throw new ServiceNotFoundException(typeof(ISettingsService));

        GoProfileCommand = ReactiveCommand.CreateFromObservable(
            () => screen.Router.Navigate.Execute(new ProfilePageViewModel(screen, User, _gmlManager))
        );

        GoModsCommand = ReactiveCommand.CreateFromObservable(
            () => screen.Router.Navigate.Execute(new ModsPageViewModel(
                screen,
                ListViewModel.SelectedProfile!,
                User,
                _gmlManager,
                _systemService))
        );

        GoSettingsCommand = ReactiveCommand.CreateFromObservable(
            () => screen.Router.Navigate.Execute(new SettingsPageViewModel(
                screen,
                LocalizationService,
                _settingsService,
                _gmlManager))
        );

        HomeCommand = ReactiveCommand.Create(async () => await LoadProfiles());

        _gmlManager.ProgressChanged.Subscribe(percentage =>
        {
            if (LoadingPercentage != percentage)
                LoadingPercentage = percentage;
        });

        _gmlManager.ProfilesChanges.Subscribe(LoadProfilesAsync);

        _closeEvent ??= onClosed.Subscribe(KillGameProcess);
        _profileNameChanged ??= ListViewModel.ProfileChanged.Subscribe(OnProfileChanged);

        _maxCountLoaded ??= _gmlManager.MaxFileCount.Subscribe(count => MaxCount = count);
        _loadedLoaded ??= _gmlManager.LoadedFilesCount.Subscribe(ChangeLoadProcessDescription);

        _speedSubscription = _gmlManager.DownloadedBytesDelta
            .Buffer(TimeSpan.FromSeconds(1))
            .ObserveOn(RxApp.MainThreadScheduler)
            .Subscribe(list =>
            {
                var total = list.Sum(x => (long)x);
                LoadingSpeed = total > 0 ? $"{FormatBytes(total)}/s" : string.Empty;
            });

        LogoutCommand = ReactiveCommand.CreateFromTask(OnLogout);

        PlayCommand = ReactiveCommand.CreateFromTask(StartGame);

        BackendIsActive = !_backendChecker.IsOffline;

        RxApp.MainThreadScheduler.Schedule(LoadData);
    }
    [Reactive] public bool IsModsButtonVisible { get; private set; }

    public new string Title => LocalizationService.GetString(ResourceKeysDictionary.MainPageTitle);

    public ICommand GoProfileCommand { get; set; }
    public ICommand GoModsCommand { get; set; }
    public ICommand LogoutCommand { get; set; }
    public ICommand PlayCommand { get; set; }
    public ICommand GoSettingsCommand { get; set; }
    public ICommand HomeCommand { get; set; }
    public ListViewModel ListViewModel { get; } = new();
    public ILauncherUser User { get; }
    public bool BackendIsActive { get; }

    [Reactive] public int? LoadingPercentage { get; set; }
    [Reactive] public int? MaxCount { get; set; }
    [Reactive] public int? LoadedCount { get; set; }

    [Reactive] public string? Headline { get; set; }

    [Reactive] public string? Description { get; set; }

    [Reactive] public string? LoadingSpeed { get; set; }

    [Reactive] public bool IsProcessing { get; set; }

    [Reactive] public ObservableCollection<NewsReadDto> News { get; set; } = [];

    private async void LoadProfilesAsync(bool eventInfo)
    {
        await LoadProfiles();
    }

    private void OnProfileChanged(ProfileReadDto? profile)
    {
        SaveSelectedServer(profile);
        UpdateModsButtonVisibility(profile);
    }
    private void UpdateModsButtonVisibility(ProfileReadDto? profile)
    {
        if (profile is null)
        {
            IsModsButtonVisible = false;
            return;
        }

        var keywords = new[]
        {
            nameof(GameLoader.Forge),
            nameof(GameLoader.Fabric),
            nameof(GameLoader.Quilt),
            nameof(GameLoader.NeoForge)
        };

        var profileName = profile.Name.ToLowerInvariant();
        var gameVersion = profile.GameVersion?.ToLowerInvariant() ?? string.Empty;
        var launchVersion = profile.LaunchVersion?.ToLowerInvariant() ?? string.Empty;

        IsModsButtonVisible = keywords.Any(keyword =>
            profileName.Contains(keyword, StringComparison.CurrentCultureIgnoreCase) ||
            gameVersion.Contains(keyword, StringComparison.CurrentCultureIgnoreCase) ||
            launchVersion.Contains(keyword, StringComparison.CurrentCultureIgnoreCase));
    }

    private void ChangeLoadProcessDescription(int count)
    {
        LoadedCount = count;

        Description =
            $"{LocalizationService.GetString(ResourceKeysDictionary.Stay)}: " +
            $"{MaxCount - LoadedCount} " +
            $"{LocalizationService.GetString(ResourceKeysDictionary.Files)}";
    }

    private async void SaveSelectedServer(ProfileReadDto? profile)
    {
        if (profile != null)
            await _storageService.SetAsync(StorageConstants.LastSelectedProfileName, profile.Name);
    }

    private Task OnLogout(CancellationToken arg)
    {
        return Dispatcher.UIThread.InvokeAsync(async () =>
        {
            await _storageService.SetAsync<IUser?>(StorageConstants.User, null);
            _mainViewModel.Router.Navigate.Execute(new LoginPageViewModel(_mainViewModel, _onClosed));
        });
    }

    private async Task StartGame()
    {
        var tokenSource = new CancellationTokenSource();
        var cancellationToken = tokenSource.Token;
        var disposable =  new CompositeDisposable();

        await ExecuteFromNewThread(async () =>
        {
            try
            {
                UpdateProgress(
                    LocalizationService.GetString(ResourceKeysDictionary.Updating),
                    LocalizationService.GetString(ResourceKeysDictionary.CheckingFileIntegrity),
                    true);

                var profileInfo = await GetProfileInfo();

                _gmlManager.Gameloader.GameLaunched
                    .ObserveOn(RxApp.MainThreadScheduler)
                    .Subscribe(c => _mainViewModel._gameLaunched.OnNext(true))
                    .DisposeWith(disposable);

                await _gmlManager.Gameloader.StartGameAsync(profileInfo, !_backendChecker.IsOffline);
            }
            catch (UnauthorizedAccessException)
            {
                await OnLogout(CancellationToken.None);
            }
            catch (ProfileNotLoadedException exception)
            {
                ShowError(ResourceKeysDictionary.Error,
                    LocalizationService.GetString(ResourceKeysDictionary.ProfileNotConfigured));
                SentrySdk.CaptureException(exception);
                Console.WriteLine(exception);
            }
            catch (FileNotFoundException exception)
            {
                ShowError(ResourceKeysDictionary.Error,
                    LocalizationService.GetString(ResourceKeysDictionary.JavaNotFound));
                SentrySdk.CaptureException(exception);
                Console.WriteLine(exception);
            }
            catch (IOException ioException) when (_systemService.IsDiskFull(ioException))
            {
                ShowError(ResourceKeysDictionary.Error,
                    LocalizationService.GetString(ResourceKeysDictionary.IsDiskFull));

                SentrySdk.CaptureException(ioException);
                Console.WriteLine(ioException);
            }
            catch (MinecraftException exception)
            {
                _logHandler.RecentLogs.Clear();
                ShowError(ResourceKeysDictionary.Error,
                    LocalizationService.GetString(SystemConstants.MinecraftExceptionStartException));

                SentrySdk.CaptureException(exception);
            }
            catch (TaskCanceledException exception)
            {
                ShowError(ResourceKeysDictionary.Error,
                    LocalizationService.GetString(SystemConstants.MinecraftExceptionStartException));

                SentrySdk.CaptureException(exception);
                Console.WriteLine(exception);
                _logHandler.RecentLogs.Clear();
            }
            catch (Exception exception)
            {
                ShowError(ResourceKeysDictionary.Error, string.Join(". ", exception.Message));

                SentrySdk.CaptureException(exception);
                Console.WriteLine(exception);
            }
            finally
            {
                disposable.Dispose();
                Dispatcher.UIThread.Invoke(() => _mainViewModel._gameLaunched.OnNext(false));
                UpdateProgress(string.Empty, string.Empty, false);
                if (!_backendChecker.IsOffline)
                {
                    await _gmlManager.UpdateDiscordRpcState(
                        LocalizationService.GetString(ResourceKeysDictionary.DefaultDRpcText));
                }
            }
        });
    }

    private async Task<ResponseMessage<ProfileReadInfoDto?>?> GetProfileInfo()
    {
        UpdateProgress(
            LocalizationService.GetString(ResourceKeysDictionary.Updating),
            LocalizationService.GetString(ResourceKeysDictionary.UpdatingDescription),
            true);

        if (!_backendChecker.IsOffline)
        {
            await _gmlManager.UpdateDiscordRpcState(
                $"{LocalizationService.GetString(ResourceKeysDictionary.PlayDRpcText)} \"{ListViewModel.SelectedProfile!.Name}\"");
        }

        var settings = await _storageService.GetAsync<SettingsInfo>(StorageConstants.Settings) ?? SettingsInfo.Default;

        var localProfile = new ProfileCreateInfoDto
        {
            ProfileName = ListViewModel.SelectedProfile!.Name,
            RamSize = CalculateRecommendedRam(settings),
            IsFullScreen = settings.FullScreen,
            OsType = ((int)_systemService.GetOsType()).ToString(),
            OsArchitecture = _systemService.GetOsArchitecture(),
            UserAccessToken = User.AccessToken,
            UserName = User.Name,
            UserUuid = User.Uuid,
            WindowWidth = settings.GameWidth,
            WindowHeight = settings.GameHeight
        };

        ResponseMessage<ProfileReadInfoDto?>? profileInfo;

        if (_backendChecker.IsOffline)
        {
            profileInfo = await _gmlManager.GetProfileInfoOffline(localProfile);
        }
        else
        {
            profileInfo = await _gmlManager.GetProfileInfo(localProfile);
        }

        if (profileInfo?.Data is { } profileData)
        {
            var maxRamMb = CalculateRecommendedRam(settings);
            var minRamMb = Math.Clamp(settings.XmsRamValueMb ?? Math.Min(2048, maxRamMb), 512, maxRamMb);
            profileData.Arguments = JavaArgumentsHelper.ConfigureJvmArguments(
                profileData.Arguments,
                settings.CustomJvmArguments,
                minRamMb,
                maxRamMb);
        }

        return profileInfo;
    }

    private int CalculateRecommendedRam(SettingsInfo settings)
    {
        var totalRamMb = (int)Math.Min(_systemService.GetMaxRam(), int.MaxValue);
        var safeMaximumMb = Math.Min(32768, Math.Max(1024, totalRamMb - 4096));

        // Xmx from the new slider takes precedence. The remaining branches preserve
        // behaviour for older settings files that don't yet contain XmxRamValueMb.
        var recommendedRam = settings.XmxRamValueMb ??
            (settings.IsDynamicRam
                ? ListViewModel.SelectedProfile?.RecommendedRam ?? 8192
                : Convert.ToInt32(settings.RamValue));

        return Math.Clamp(recommendedRam, 1024, safeMaximumMb);
    }

    private static string FormatBytes(long bytes)
    {
        const int scale = 1024;
        string[] orders = ["B", "KB", "MB", "GB", "TB"];
        double max = bytes;
        int order = 0;
        while (max >= scale && order < orders.Length - 1)
        {
            order++;
            max /= scale;
        }
        return string.Format(System.Globalization.CultureInfo.InvariantCulture, "{0:0.##} {1}", max, orders[order]);
    }

    private void UpdateProgress(string headline, string description, bool isProcessing, int? percentage = null)
    {

        Dispatcher.UIThread.Invoke(() =>
        {
            Headline = headline;
            Description = description;
            IsProcessing = isProcessing;
            LoadingPercentage = percentage;
            if (!IsProcessing)
                LoadingSpeed = string.Empty;
        });
    }

    private async void KillGameProcess(bool isClosed)
    {
        try
        {
            _gmlManager.Gameloader.ForceStop();
        }
        catch (Exception exception)
        {
            SentrySdk.CaptureException(exception);
        }
    }

    private async void LoadData()
    {
        try
        {
            await LoadProfiles();
            await LoadNews();

            if (!_backendChecker.IsOffline)
            {
                await _gmlManager.LoadDiscordRpc();
                await _gmlManager.UpdateDiscordRpcState(
                    LocalizationService.GetString(ResourceKeysDictionary.DefaultDRpcText));
            }
        }
        catch (TaskCanceledException exception)
        {
            SentrySdk.CaptureException(exception);
            Console.WriteLine(exception);
            await Reconnect();
        }
        catch (HttpRequestException exception)
        {
            SentrySdk.CaptureException(exception);
            Console.WriteLine(exception);
            await Reconnect();
        }
        catch (Exception exception)
        {
            SentrySdk.CaptureException(exception);
        }
    }

    private async Task LoadNews()
    {
        try
        {
            if (_backendChecker.IsOffline)
            {
                News =
                [
                    new NewsReadDto
                    {
                        Title = LocalizationService.GetString(ResourceKeysDictionary.NewsOffline),
                        Content =
                            $"<div style='text-align: center; margin-top: 100 px; margin-bottom: 100 px;'>{LocalizationService.GetString(ResourceKeysDictionary.NewsOffline)}</div>",
                        Date = null,
                        Type = NewsListenerType.Custom
                    }
                ];
                return;
            }

            var news = await _gmlManager.GetNews();

            if (news.Data?.Count == 0)
            {
                News =
                [
                    new NewsReadDto
                    {
                        Title = LocalizationService.GetString(ResourceKeysDictionary.NewsEmptyTitle),
                        Content =
                            $"<div style='text-align: center; margin-top: 100 px; margin-bottom: 100 px;'>{LocalizationService.GetString(ResourceKeysDictionary.NewsEmptyContent)}</div>",
                        Date = null,
                        Type = NewsListenerType.Custom
                    }
                ];
            }
            else
            {
                News = new ObservableCollection<NewsReadDto>(news.Data ?? []);
            }
            ;
        }
        catch (Exception e)
        {
            Console.WriteLine(e);
        }
    }

    private async Task LoadProfiles()
    {
        ResponseMessage<List<ProfileReadDto>> profilesData;
        if (_backendChecker.IsOffline)
        {
            profilesData = await _gmlManager.GetOfflineProfiles();
        }
        else
        {
            profilesData = await _gmlManager.GetProfiles(User.AccessToken);
        }

        ListViewModel.Profiles = new ObservableCollection<ProfileReadDto>(profilesData.Data ?? []);

        var lastSelectedProfileName = await _storageService.GetAsync<string>(StorageConstants.LastSelectedProfileName);

        if (!string.IsNullOrEmpty(lastSelectedProfileName) &&
            ListViewModel.Profiles.FirstOrDefault(c => c.Name == lastSelectedProfileName) is { } profile)
            ListViewModel.SelectedProfile = profile;

        ListViewModel.SelectedProfile ??= ListViewModel.Profiles.FirstOrDefault();

        // НОВОЕ: Устанавливаем начальное состояние видимости кнопки при первой загрузке
        UpdateModsButtonVisibility(ListViewModel.SelectedProfile);
    }

    private async Task Reconnect()
    {
        _mainViewModel.Manager
            .CreateMessage()
            .Accent("#F15B19")
            .Background("#111111")
            .HasHeader(LocalizationService.GetString(ResourceKeysDictionary.LostConnection))
            .HasMessage(LocalizationService.GetString(ResourceKeysDictionary.Reconnecting))
            .WithOverlay(new ProgressBar
            {
                VerticalAlignment = VerticalAlignment.Bottom,
                HorizontalAlignment = HorizontalAlignment.Stretch,
                Height = 2,
                BorderThickness = new Thickness(0),
                Foreground = new SolidColorBrush(Color.FromArgb(128, 255, 255, 255)),
                Background = Brushes.Transparent,
                IsIndeterminate = true,
                IsHitTestVisible = false
            })
            .Dismiss()
            .WithDelay(TimeSpan.FromSeconds(5))
            .Queue();

        await Task.Delay(TimeSpan.FromSeconds(5));

        LoadData();
    }
}
